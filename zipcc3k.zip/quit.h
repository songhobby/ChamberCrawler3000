#ifndef __QUIT__H__
#define __QUIT__H__

class Quit{};

#endif
