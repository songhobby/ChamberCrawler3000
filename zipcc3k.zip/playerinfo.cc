#include<string>
#include"playerinfo.h"
using namespace std;

