#ifndef __BOOST_ATK_H__
#define __BOOST_ATK_H__
#include "potion.h"
#include "info.h"

class Boost_Atk final:public Potion {
	public:
	Boost_Atk (int posx, int posy);
};

#endif


