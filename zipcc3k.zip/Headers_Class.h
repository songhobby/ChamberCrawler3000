#ifndef __HEADERS__
#define __HEADERS__

class Aaron;
class Shade;

class Drow;
class Vampire;
class Troll;
class Goblin;
class Human;
class Dwarf;
class Halfling;
class Elf;
class Orc;
class Dragon;
class Merchant;
class Small_Hoard;
class Normal_Hoard;
class Dragon_Hoard;
class Merchant_Hoard;
class Restore_Health;
class Boost_Atk;
class Boost_Def;
class Poison_Health;
class Wound_Atk;
class Wound_Def;
class Space;
class Vertical_Wall;
class Horizontal_Wall;
class Door;
class Tile;
class Passage;
class Stair;
class BloodElf;
class NightElf;
class Worgen;
class ForSaken ;
class Eason;

#endif
