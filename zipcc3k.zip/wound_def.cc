#include "wound_def.h"

	

Wound_Def::Wound_Def (int posx, int posy)
:Potion{posx, posy, WOUND_DEF} {}
