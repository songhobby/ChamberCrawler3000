#ifndef _CHAMBER_H_
#define _CHAMBER_H_
#include <vector>

struct Chamber {
	std::vector<std::shared_ptr<Object>*> c;
};

#endif

