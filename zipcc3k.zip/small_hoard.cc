#include "small_hoard.h"
#include "type.h"


Small_Hoard::Small_Hoard (int row, int col)
	:Treasure{row, col, SMALL_HOARD, 1} {}

