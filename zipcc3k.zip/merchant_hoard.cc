#include "merchant_hoard.h"
#include "type.h"
#include "style.h"


Merchant_Hoard::Merchant_Hoard (int row, int col)
	:Treasure{row, col, MERCHANT_HOARD, 4} {}
