#include "boost_def.h"

	

Boost_Def::Boost_Def (int posx, int posy)
:Potion{posx, posy, BOOST_DEF} {}
