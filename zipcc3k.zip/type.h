#ifndef _TYPE_H_
#define _TYPE_H_

enum Type{
    PICKUP,
	ATTACK,
	BUY,
	MOVE
};



#endif
