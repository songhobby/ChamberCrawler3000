#ifndef __WOUND_ATK_H__
#define __WOUND_ATK_H__
#include "potion.h"
#include "info.h"

class Wound_Atk final:public Potion {
	public:
	Wound_Atk (int posx, int posy);
};

#endif


