#ifndef _FLOORTILE_H_                                                   
#define _SUBSCRIPTIONS_H_

enum FloorTile { 
	player,
	stairway,
	potion,
	gold,
	enemy,
	wall,
	door,
	passage,
	ground,
	space
};

#endif
  ~                 
