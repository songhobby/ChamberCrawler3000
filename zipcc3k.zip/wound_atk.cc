#include "wound_atk.h"

using namespace std;

Wound_Atk::Wound_Atk (int posx, int posy)
:Potion{posx, posy, WOUND_ATK} {}
