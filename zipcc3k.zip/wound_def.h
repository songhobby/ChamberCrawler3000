#ifndef __WOUND_DEF_H__
#define __WOUND_DEF_H__
#include "potion.h"
#include "info.h"

class Wound_Def final:public Potion {
	public:
	Wound_Def (int posx, int posy);
};

#endif


