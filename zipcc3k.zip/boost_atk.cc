#include "boost_atk.h"

	
Boost_Atk::Boost_Atk (int posx, int posy)
:Potion{posx, posy, BOOST_ATK} {}
