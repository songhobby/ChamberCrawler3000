#include "style.h"
#include <string>

struct VisitExcept{
    std::string state;
    int num;
};
