#ifndef __BOOST_DEF_H__
#define __BOOST_DEF_H__
#include "potion.h"
#include "info.h"

class Boost_Def final:public Potion {
	public:
	Boost_Def (int posx, int posy);
};

#endif


